﻿
namespace salgados
{
    partial class FormPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxCliente = new System.Windows.Forms.ComboBox();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblSalgado = new System.Windows.Forms.Label();
            this.cbxSalgado = new System.Windows.Forms.ComboBox();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.lblPreco = new System.Windows.Forms.Label();
            this.txtId_Salgado = new System.Windows.Forms.TextBox();
            this.lblId_Salgado = new System.Windows.Forms.Label();
            this.btnAdicionar_Salgado = new System.Windows.Forms.Button();
            this.dgvPedido = new System.Windows.Forms.DataGridView();
            this.btnAtualizar_Salgado = new System.Windows.Forms.Button();
            this.btnExcluir_Salgado = new System.Windows.Forms.Button();
            this.btnNovo_Pedido = new System.Windows.Forms.Button();
            this.btnFinalizar_peddido = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.txtPreco_Total = new System.Windows.Forms.TextBox();
            this.lblPreco_Total = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedido)).BeginInit();
            this.SuspendLayout();
            // 
            // cbxCliente
            // 
            this.cbxCliente.FormattingEnabled = true;
            this.cbxCliente.Location = new System.Drawing.Point(12, 39);
            this.cbxCliente.Name = "cbxCliente";
            this.cbxCliente.Size = new System.Drawing.Size(343, 21);
            this.cbxCliente.TabIndex = 0;
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCliente.Location = new System.Drawing.Point(12, 20);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(46, 13);
            this.lblCliente.TabIndex = 1;
            this.lblCliente.Text = "Cliente";
            // 
            // lblSalgado
            // 
            this.lblSalgado.AutoSize = true;
            this.lblSalgado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalgado.Location = new System.Drawing.Point(12, 83);
            this.lblSalgado.Name = "lblSalgado";
            this.lblSalgado.Size = new System.Drawing.Size(53, 13);
            this.lblSalgado.TabIndex = 3;
            this.lblSalgado.Text = "Salgado";
            // 
            // cbxSalgado
            // 
            this.cbxSalgado.FormattingEnabled = true;
            this.cbxSalgado.Location = new System.Drawing.Point(12, 102);
            this.cbxSalgado.Name = "cbxSalgado";
            this.cbxSalgado.Size = new System.Drawing.Size(343, 21);
            this.cbxSalgado.TabIndex = 2;
            this.cbxSalgado.SelectedIndexChanged += new System.EventHandler(this.cbxSalgado_SelectedIndexChanged);
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantidade.Location = new System.Drawing.Point(12, 143);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(72, 13);
            this.lblQuantidade.TabIndex = 4;
            this.lblQuantidade.Text = "Quantidade";
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(15, 159);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(80, 20);
            this.txtQuantidade.TabIndex = 5;
            this.txtQuantidade.Leave += new System.EventHandler(this.txtQuantidade_Leave);
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(15, 204);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(80, 20);
            this.txtPreco.TabIndex = 7;
            // 
            // lblPreco
            // 
            this.lblPreco.AutoSize = true;
            this.lblPreco.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco.Location = new System.Drawing.Point(12, 188);
            this.lblPreco.Name = "lblPreco";
            this.lblPreco.Size = new System.Drawing.Size(40, 13);
            this.lblPreco.TabIndex = 6;
            this.lblPreco.Text = "Preço";
            // 
            // txtId_Salgado
            // 
            this.txtId_Salgado.Location = new System.Drawing.Point(15, 246);
            this.txtId_Salgado.Name = "txtId_Salgado";
            this.txtId_Salgado.Size = new System.Drawing.Size(80, 20);
            this.txtId_Salgado.TabIndex = 9;
            // 
            // lblId_Salgado
            // 
            this.lblId_Salgado.AutoSize = true;
            this.lblId_Salgado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId_Salgado.Location = new System.Drawing.Point(12, 230);
            this.lblId_Salgado.Name = "lblId_Salgado";
            this.lblId_Salgado.Size = new System.Drawing.Size(70, 13);
            this.lblId_Salgado.TabIndex = 8;
            this.lblId_Salgado.Text = "ID Salgado";
            // 
            // btnAdicionar_Salgado
            // 
            this.btnAdicionar_Salgado.BackColor = System.Drawing.Color.Red;
            this.btnAdicionar_Salgado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdicionar_Salgado.Location = new System.Drawing.Point(193, 159);
            this.btnAdicionar_Salgado.Name = "btnAdicionar_Salgado";
            this.btnAdicionar_Salgado.Size = new System.Drawing.Size(121, 23);
            this.btnAdicionar_Salgado.TabIndex = 10;
            this.btnAdicionar_Salgado.Text = "Adicionar Salgado";
            this.btnAdicionar_Salgado.UseVisualStyleBackColor = false;
            this.btnAdicionar_Salgado.Click += new System.EventHandler(this.btnAdicionar_Salgado_Click);
            // 
            // dgvPedido
            // 
            this.dgvPedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPedido.Location = new System.Drawing.Point(12, 282);
            this.dgvPedido.Name = "dgvPedido";
            this.dgvPedido.Size = new System.Drawing.Size(583, 166);
            this.dgvPedido.TabIndex = 11;
            this.dgvPedido.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPedido_CellClick);
            // 
            // btnAtualizar_Salgado
            // 
            this.btnAtualizar_Salgado.BackColor = System.Drawing.Color.Red;
            this.btnAtualizar_Salgado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAtualizar_Salgado.Location = new System.Drawing.Point(193, 201);
            this.btnAtualizar_Salgado.Name = "btnAtualizar_Salgado";
            this.btnAtualizar_Salgado.Size = new System.Drawing.Size(121, 23);
            this.btnAtualizar_Salgado.TabIndex = 12;
            this.btnAtualizar_Salgado.Text = "Atualizar Salgado";
            this.btnAtualizar_Salgado.UseVisualStyleBackColor = false;
            this.btnAtualizar_Salgado.Click += new System.EventHandler(this.btnAtualizar_Salgado_Click);
            // 
            // btnExcluir_Salgado
            // 
            this.btnExcluir_Salgado.BackColor = System.Drawing.Color.Red;
            this.btnExcluir_Salgado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcluir_Salgado.Location = new System.Drawing.Point(193, 246);
            this.btnExcluir_Salgado.Name = "btnExcluir_Salgado";
            this.btnExcluir_Salgado.Size = new System.Drawing.Size(121, 23);
            this.btnExcluir_Salgado.TabIndex = 13;
            this.btnExcluir_Salgado.Text = "Excluir Salgado";
            this.btnExcluir_Salgado.UseVisualStyleBackColor = false;
            this.btnExcluir_Salgado.Click += new System.EventHandler(this.btnExcluir_Salgado_Click);
            // 
            // btnNovo_Pedido
            // 
            this.btnNovo_Pedido.BackColor = System.Drawing.Color.Red;
            this.btnNovo_Pedido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNovo_Pedido.Location = new System.Drawing.Point(483, 37);
            this.btnNovo_Pedido.Name = "btnNovo_Pedido";
            this.btnNovo_Pedido.Size = new System.Drawing.Size(112, 23);
            this.btnNovo_Pedido.TabIndex = 14;
            this.btnNovo_Pedido.Text = "Novo Pedido";
            this.btnNovo_Pedido.UseVisualStyleBackColor = false;
            this.btnNovo_Pedido.Click += new System.EventHandler(this.btnNovo_Pedido_Click);
            // 
            // btnFinalizar_peddido
            // 
            this.btnFinalizar_peddido.BackColor = System.Drawing.Color.Red;
            this.btnFinalizar_peddido.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinalizar_peddido.Location = new System.Drawing.Point(483, 66);
            this.btnFinalizar_peddido.Name = "btnFinalizar_peddido";
            this.btnFinalizar_peddido.Size = new System.Drawing.Size(112, 23);
            this.btnFinalizar_peddido.TabIndex = 15;
            this.btnFinalizar_peddido.Text = "Finalizar Pedido";
            this.btnFinalizar_peddido.UseVisualStyleBackColor = false;
            this.btnFinalizar_peddido.Click += new System.EventHandler(this.btnFinalizar_peddido_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Red;
            this.btnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(483, 95);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(112, 23);
            this.btnSair.TabIndex = 16;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // txtPreco_Total
            // 
            this.txtPreco_Total.Location = new System.Drawing.Point(515, 249);
            this.txtPreco_Total.Name = "txtPreco_Total";
            this.txtPreco_Total.Size = new System.Drawing.Size(80, 20);
            this.txtPreco_Total.TabIndex = 17;
            // 
            // lblPreco_Total
            // 
            this.lblPreco_Total.AutoSize = true;
            this.lblPreco_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco_Total.Location = new System.Drawing.Point(512, 233);
            this.lblPreco_Total.Name = "lblPreco_Total";
            this.lblPreco_Total.Size = new System.Drawing.Size(73, 13);
            this.lblPreco_Total.TabIndex = 18;
            this.lblPreco_Total.Text = "Preço Total";
            // 
            // FormPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.BackgroundImage = global::salgados.Properties.Resources.salagdos_fundo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(607, 460);
            this.Controls.Add(this.lblPreco_Total);
            this.Controls.Add(this.txtPreco_Total);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnFinalizar_peddido);
            this.Controls.Add(this.btnNovo_Pedido);
            this.Controls.Add(this.btnExcluir_Salgado);
            this.Controls.Add(this.btnAtualizar_Salgado);
            this.Controls.Add(this.dgvPedido);
            this.Controls.Add(this.btnAdicionar_Salgado);
            this.Controls.Add(this.txtId_Salgado);
            this.Controls.Add(this.lblId_Salgado);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.lblPreco);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.lblSalgado);
            this.Controls.Add(this.cbxSalgado);
            this.Controls.Add(this.lblCliente);
            this.Controls.Add(this.cbxCliente);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormPedido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormPedido";
            this.Load += new System.EventHandler(this.FormPedido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedido)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxCliente;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.Label lblSalgado;
        private System.Windows.Forms.ComboBox cbxSalgado;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label lblPreco;
        private System.Windows.Forms.TextBox txtId_Salgado;
        private System.Windows.Forms.Label lblId_Salgado;
        private System.Windows.Forms.Button btnAdicionar_Salgado;
        private System.Windows.Forms.DataGridView dgvPedido;
        private System.Windows.Forms.Button btnAtualizar_Salgado;
        private System.Windows.Forms.Button btnExcluir_Salgado;
        private System.Windows.Forms.Button btnNovo_Pedido;
        private System.Windows.Forms.Button btnFinalizar_peddido;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox txtPreco_Total;
        private System.Windows.Forms.Label lblPreco_Total;
    }
}